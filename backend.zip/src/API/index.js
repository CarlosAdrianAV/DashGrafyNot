import axios from 'axios';

export const getOrders = () => {
  return axios.get("https://dummyjson.com/carts/1").then((res) => res.data);
};

export const getRevenue = () => {
  return axios.get("https://dummyjson.com/carts").then((res) => res.data);
};

export const getInventory = () => {
  return axios.get("http://localhost:5000/api/notes").then((res) => res.data);
};

export const getCustomers = () => {
  return axios.get("https://dummyjson.com/users").then((res) => res.data);
};

export const getComments = () => {
  return axios.get("https://dummyjson.com/comments").then((res) => res.data);
};