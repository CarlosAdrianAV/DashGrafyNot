import { Typography } from "antd";

function AppFooter() {
  return (
    <div className="AppFooter">
      <Typography.Link href="#" target={"_blank"}>
        2024
      </Typography.Link>
      <Typography.Link href="#" target={"_blank"}>
        Taller De Software Web
      </Typography.Link>
    </div>
  );
}
export default AppFooter;
