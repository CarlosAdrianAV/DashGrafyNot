import {
  UserOutlined,
  RadarChartOutlined,
  TrophyOutlined,
} from "@ant-design/icons";
import { Card, Space, Statistic, Table, Typography } from "antd";
import { useEffect, useState } from "react";
import { getCustomers, getInventory, getOrders, getRevenue } from "../../API";
import { getTopThreePromedios } from '../Historial de notas';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
} from "chart.js";
import { Bar } from "react-chartjs-2";
import './Dashboard.css'; 

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

function Dashboard() {
  const [orders, setOrders] = useState(0);
  const [inventory, setInventory] = useState(0);
  const [customers, setCustomers] = useState(0);
  const [revenue, setRevenue] = useState(0);
  const [coursesBelowPassing, setCoursesBelowPassing] = useState(0);
  const [coursesAbovePassing, setCoursesAbovePassing] = useState(0);
  const [averageFinalAverages, setAverageFinalAverages] = useState(0);
  const [topThreePromedios, setTopThreePromedios] = useState([]);
  const [gradeImprovementRatio, setGradeImprovementRatio] = useState(0);

  useEffect(() => {
    getInventory()
      .then((res) => {
        if (Array.isArray(res)) {
          // Filtrar cursos que no pasan
          const belowPassingCount = res.filter(item => parseFloat(item.promedio_final) <= 10.5).length;
          setCoursesBelowPassing(belowPassingCount);

          // Obtener los tres mejores promedios finales
          const topThree = getTopThreePromedios();
          setTopThreePromedios(topThree);
        } else {
          console.error("Datos recibidos no son un array:", res);
        }
      })
      .catch(error => {
        console.error("Error al obtener datos:", error);
      });

    getOrders().then((res) => {
      setOrders(res.total);
      setRevenue(res.discountedTotal);
    });
    getInventory().then((res) => {
      setInventory(res.total);
    });
    getCustomers().then((res) => {
      setCustomers(res.total);
    });
  }, []);

  useEffect(() => {
    getInventory()
      .then((res) => {
        if (Array.isArray(res)) {
          // Filtrar cursos que pasan
          const abovePassingCount = res.filter(item => parseFloat(item.promedio_final) > 10.5).length;
          setCoursesAbovePassing(abovePassingCount);
        } else {
          console.error("Datos recibidos no son un array:", res);
        }
      })
      .catch(error => {
        console.error("Error al obtener datos:", error);
      });

    getOrders().then((res) => {
      setOrders(res.total);
      setRevenue(res.discountedTotal);
    });
    getInventory().then((res) => {
      setInventory(res.total);
    });
    getCustomers().then((res) => {
      setCustomers(res.total);
    });
  }, []);


  useEffect(() => {
    getInventory()
      .then((res) => {
        if (Array.isArray(res)) {
          // Calcular promedio de promedios finales
          const totalPromedioFinal = res.reduce((acc, item) => acc + parseFloat(item.promedio_final), 0);
          const avgFinalAverages = totalPromedioFinal / res.length;
          setAverageFinalAverages(avgFinalAverages);
        } else {
          console.error("Datos recibidos no son un array:", res);
        }
      })
      .catch(error => {
        console.error("Error al obtener datos:", error);
      });

    getOrders().then((res) => {
      setOrders(res.total);
      setRevenue(res.discountedTotal);
    });
    getInventory().then((res) => {
      setInventory(res.total);
    });
    getCustomers().then((res) => {
      setCustomers(res.total);
    });
  }, []);

  return (
    <Space size={20} color="green" direction="vertical">
      <Typography.Title level={4}>Indicadores Clave</Typography.Title>
      <Space direction="horizontal">
        <DashboardCard
          icon={
            <RadarChartOutlined
              style={{
                color: "green",
                backgroundColor: "white",
                borderRadius: 20,
                fontSize: 24,
                padding: 8,
              }}
            />
          }
          title={"Promedio de notas"}
          value={averageFinalAverages.toFixed(2)}
        />

        <DashboardCard
          icon={
            <UserOutlined
              style={{
                color: "purple",
                backgroundColor: "white",
                borderRadius: 20,
                fontSize: 24,
                padding: 8,
              }}
            />
          }
          title={"Cursos aprobados"}
          value={coursesAbovePassing}
          font="Times New Roman" // Ejemplo de fuente dinámica
          color="red" // Ejemplo de color de letra dinámico
        />
        <DashboardCard
          icon={
            <TrophyOutlined
              style={{
                color: "red",
                backgroundColor: "white",
                borderRadius: 20,
                fontSize: 24,
                padding: 8,
              }}
            />
          }
          title={"Cursos desaprobados"}
          value={coursesBelowPassing}
          font="Verdana" // Ejemplo de fuente dinámica
          color="green" // Ejemplo de color de letra dinámico
        />
      </Space>
      <Space>
        <RecentOrders topThreePromedios={topThreePromedios} />
        <DashboardChart />
      </Space>
    </Space>
  );
}

function DashboardCard({ title, value, icon, font, color }) {
  const cardStyle = {
    fontFamily: font,
    color: color,
  };

  return (
    <Card className="dashboard-card" style={cardStyle}>
      <Space direction="horizontal">
        {icon}
        <Statistic title={title} value={value} />
      </Space>
    </Card>
  );
}

function RecentOrders({ topThreePromedios }) {
  const [dataSource, setDataSource] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    setDataSource(topThreePromedios);
    setLoading(false);
  }, [topThreePromedios]);

  return (
    <>
      <Typography.Title level={4}>Top 3 de Notas</Typography.Title>
      <Table
        columns={[
          {
            title: "CURSO",
            dataIndex: "curso",
          },
          {
            title: "Promedio Final",
            dataIndex: "promedio_final",
          },
        ]}
        loading={loading}
        dataSource={dataSource}
        pagination={false}
      ></Table>
    </>
  );
}

function DashboardChart() {
  const [chartData, setChartData] = useState({
    labels: [],
    datasets: [],
  });

  useEffect(() => {
    getInventory().then((res) => {
      if (Array.isArray(res)) {
        const labels = res.map((item) => item.curso);
        const data = res.map((item) => parseFloat(item.promedio_final));
        const dataSource = {
          labels,
          datasets: [
            {
              label: "Promedio Final",
              data: data,
              backgroundColor: "rgba(75, 192, 192, 0.6)",
              borderColor: "rgba(75, 192, 192, 2.3)",
              borderWidth: 1,
            },
          ],
        };

        setChartData(dataSource);
      } else {
        console.error("Datos recibidos no son un array:", res);
      }
    }).catch((error) => {
      console.error("Error al obtener datos:", error);
    });
  }, []);

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: "bottom",
      },
      title: {
        display: true,
        text: "Promedio Final por Curso",
      },
    },
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  };

  return (
    <Card style={{ width: 500, height: 250 }}>
      <Bar options={options} data={chartData} />
    </Card>
  );
}

export default Dashboard;


