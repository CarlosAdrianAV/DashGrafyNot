  import { Space, Table, Typography } from "antd";
  import { useEffect, useState } from "react";
  import { getInventory } from "../../API";

  let topThreePromedios = [];

  function HistorialDeNotas() {
    const [loading, setLoading] = useState(false);
    const [dataSource, setDataSource] = useState([]);
    const [averageNotaParcial, setAverageNotaParcial] = useState(0);

    useEffect(() => {
      setLoading(true);
      getInventory()
        .then((res) => {
          console.log(res); // Verificar los datos recibidos

          if (Array.isArray(res)) {
            const updatedData = res.map((item) => ({
              ...item,
              promedio_final: (
                0.3 * item.nota_parcial +
                0.3 * item.evaluacion_continua +
                0.4 * item.nota_final
              ).toFixed(2),
            }));
            setDataSource(updatedData);

            // Calcular promedio de notas parciales
            const totalNotaParcial = updatedData.reduce((acc, item) => acc + item.nota_parcial, 0);
            const count = updatedData.length;
            setAverageNotaParcial((totalNotaParcial / count).toFixed(2));

            // Obtener los tres mejores promedios finales
            topThreePromedios = updatedData
              .sort((a, b) => b.promedio_final - a.promedio_final)
              .slice(0, 3);
          } else {
            console.error("Datos recibidos no son un array:", res);
          }
          setLoading(false);
        })
        .catch((error) => {
          console.error("Error al obtener datos:", error);
          setLoading(false);
        });
    }, []);

    const columns = [
      {
        title: "Curso",
        dataIndex: "curso",
        filters: [
          { "text": "Estructuras de Datos", "value": "Estructuras de Datos" },
  { "text": "Seguridad Informática", "value": "Seguridad Informática" },
  { "text": "Pruebas de Software", "value": "Pruebas de Software" },
  { "text": "Inteligencia Artificial", "value": "Inteligencia Artificial" },
  { "text": "Cómputo de Alto Rendimiento", "value": "Cómputo de Alto Rendimiento" },
  { "text": "Algoritmos", "value": "Algoritmos" },
  { "text": "Visión por Computador", "value": "Visión por Computador" },
  { "text": "Diseño de Software", "value": "Diseño de Software" },
  { "text": "Arquitectura de Software", "value": "Arquitectura de Software" },
  { "text": "Machine Learning", "value": "Machine Learning" },
  { "text": "Programación Concurrente", "value": "Programación Concurrente" },
  { "text": "Fundamentos de Programación", "value": "Fundamentos de Programación" },
  { "text": "Ingeniería de Software", "value": "Ingeniería de Software" },
  { "text": "Bases de Datos", "value": "Bases de Datos" },
  { "text": "Interacción Humano-Computadora", "value": "Interacción Humano-Computadora" },
  { "text": "Blockchain", "value": "Blockchain" },
  { "text": "Bioinformática", "value": "Bioinformática" },
  { "text": "Procesamiento de Lenguaje Natural", "value": "Procesamiento de Lenguaje Natural" },
  { "text": "Metodologías Ágiles", "value": "Metodologías Ágiles" },
  { "text": "DevOps", "value": "DevOps" },
  { "text": "Computación Distribuida", "value": "Computación Distribuida" },
  { "text": "Sistemas Operativos", "value": "Sistemas Operativos" },
  { "text": "Ciberseguridad", "value": "Ciberseguridad" },
  { "text": "Calidad de Software", "value": "Calidad de Software" },
  { "text": "Big Data", "value": "Big Data" },
  { "text": "Computación en la Nube", "value": "Computación en la Nube" },
  { "text": "Gestión de Proyectos", "value": "Gestión de Proyectos" },
  { "text": "Internet de las Cosas", "value": "Internet de las Cosas" },
  { "text": "Computación Gráfica", "value": "Computación Gráfica" },
  { "text": "Modelado y Simulación", "value": "Modelado y Simulación" },
  { "text": "Robótica", "value": "Robótica" }
        ],
        onFilter: (value, record) => record.curso.includes(value),
      },
      {
        title: "Nota Parcial",
        dataIndex: "nota_parcial",
        sorter: (a, b) => a.nota_parcial - b.nota_parcial,
      },
      {
        title: "Evaluación Continua",
        dataIndex: "evaluacion_continua",
        sorter: (a, b) => a.evaluacion_continua - b.evaluacion_continua,
      },
      {
        title: "Nota Final",
        dataIndex: "nota_final",
        sorter: (a, b) => a.nota_final - b.nota_final,
      },
      {
        title: "Promedio Final",
        dataIndex: "promedio_final",
        key: "promedio_final",
        sorter: (a, b) => a.promedio_final - b.promedio_final,
      },
    ];

    return (
      <Space size={20} direction="vertical">
        <Typography.Title level={4}>Historial de Notas</Typography.Title>
        <Table
          loading={loading}
          columns={columns}
          dataSource={dataSource}
          pagination={{
            pageSize: 7,
          }}
          rowKey="_id" // Asegura que cada fila tenga una clave única basada en el campo _id
        />
      </Space>
    );
  }

  export const getTopThreePromedios = () => {
    return topThreePromedios;
  };

  export default HistorialDeNotas;