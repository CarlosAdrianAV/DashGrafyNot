const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();
const port = 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Conexión a la base de datos MongoDB
mongoose.connect("mongodb://localhost:27017/NotasPorAlumno", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Esquema y modelo de Mongoose para Notas
const noteSchema = new mongoose.Schema({
  curso: String,
  nota_parcial: Number,
  nota_final: Number,
  evaluacion_continua: Number,
  promedio_final: Number,
});
const Note = mongoose.model("Note", noteSchema);

// Esquema y modelo de Mongoose para Alumnos (dentro de la misma base de datos)
const alumnoSchema = new mongoose.Schema({
  nombre: String,
  apellido: String,
  carrera: String,
});
const Alumno = mongoose.model("alumnos", alumnoSchema); // 'alumnos' es la colección dentro de 'NotasPorAlumno'

// Endpoint para obtener notas
app.get("/api/notes", async (req, res) => {
  try {
    const notes = await Note.find();
    console.log("Datos de notas obtenidos de MongoDB:", notes); 
    res.json(notes);
  } catch (error) {
    console.error("Error al obtener notas:", error);
    res.status(500).json({ message: error.message });
  }
});

// Endpoint para obtener alumnos
app.get("/api/alumnos", async (req, res) => {
  try {
    const alumnos = await Alumno.find();
    console.log("Datos de alumnos obtenidos de MongoDB:", alumnos); 
    res.json(alumnos);
  } catch (error) {
    console.error("Error al obtener alumnos:", error);
    res.status(500).json({ message: error.message });
  }
});

// Iniciar el servidor
app.listen(port, () => {
  console.log(`Servidor escuchando en http://localhost:${port}`);
});